package com.study.controller;

import javax.annotation.PostConstruct;

import org.apache.tomcat.util.http.parser.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.study.bean.RequestModel;
import com.study.bean.ResposeModel;
import com.study.bean.getAllCustomerModel;
import com.study.data.CustomerData;
import com.study.service.customerSvc;


@Controller
@RestController
public class StudyController {
	@Autowired
	customerSvc oCustomerService;
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@GetMapping(value="/study",consumes = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public String getData() {
		
	return "Spring boot study";
	}
	
	@PostMapping(value ="/fetchCustomer",consumes = {org.springframework.http.MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody  ResposeModel fetchCustomer(@RequestBody RequestModel oRequest) {
		System.out.println(oRequest.getMobileNo());
		log.info("Inside fetch"+oRequest.getMobileNo());
		ResposeModel oRes = new ResposeModel();
		oRes=oCustomerService.fetchCustomer(oRequest);
		if(oRes!=null && oRes.getName()!=null) {
			
		}else {
			oRes.setErrorMessage("No data found");
		}
		
		return oRes;
		
	}
	
	@GetMapping(value="/getAllCustomer")
	public @ResponseBody getAllCustomerModel fectchAllCustomer() {
		log.info("Inside fetch all customer");
		getAllCustomerModel oRes = new getAllCustomerModel();
		oRes=oCustomerService.fetchAllCustomer();
		return oRes;
		
	}

	@PostMapping(value="/registerCustomer",consumes= {org.springframework.http.MediaType.APPLICATION_JSON_VALUE})
	public String registerCustomer(@RequestBody CustomerData oRequestModel) {
		log.info("Inside Register customer");
		boolean status=oCustomerService.saveCustomer(oRequestModel);
		if(status)
		return "Data successfully inserted/Updated"
				+ "";
		else
			return"Insert failed";
		
	}
}
