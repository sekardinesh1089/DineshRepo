package com.study.bean;

import java.util.List;

import org.springframework.stereotype.Component;

import com.study.data.CustomerData;

@Component
public class getAllCustomerModel {
	
	public List<CustomerData> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<CustomerData> customerList) {
		this.customerList = customerList;
	}

	private List<CustomerData> customerList;

}
