package com.study.service;

import com.study.bean.RequestModel;
import com.study.bean.ResposeModel;
import com.study.bean.getAllCustomerModel;
import com.study.data.CustomerData;

public interface customerSvc {

	ResposeModel fetchCustomer(RequestModel oRequest);
	getAllCustomerModel fetchAllCustomer();
    public boolean saveCustomer(CustomerData oRequestModel);
}
