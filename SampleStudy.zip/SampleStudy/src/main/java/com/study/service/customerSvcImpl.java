package com.study.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataLocationNotFoundException;
import org.springframework.stereotype.Service;

import com.study.JPARepository.CustomerRepository;
import com.study.bean.RequestModel;
import com.study.bean.ResposeModel;
import com.study.bean.getAllCustomerModel;
import com.study.data.CustomerData;

import ch.qos.logback.core.joran.util.beans.BeanUtil;

@Service
public class customerSvcImpl implements customerSvc {
	
	private final Logger oLog = LoggerFactory.getLogger(this.getClass());
	@Autowired
	CustomerRepository customerRepository;
	public ResposeModel fetchCustomer(RequestModel oRequest) {
		// TODO Auto-generated method stub
		ResposeModel oResposeModel=new ResposeModel();
		CustomerData oCustomerData = new CustomerData();
		Optional<CustomerData> custList=customerRepository.findById(oRequest.getMobileNo());
		if(custList.isPresent()) {
			oCustomerData=custList.get();
			BeanUtils.copyProperties(oCustomerData, oResposeModel);
		}else {
			oResposeModel.setErrorMessage("No data found");
		}
		oLog.info("Inside serviceimpl class---->"+oRequest.getMobileNo());
		return oResposeModel;
	}
	@Override
	public getAllCustomerModel fetchAllCustomer() {
		getAllCustomerModel ogetAllCustomerModel = new getAllCustomerModel();
		ogetAllCustomerModel.setCustomerList((List<CustomerData>) customerRepository.findAll());
	
		return ogetAllCustomerModel;
	}
	@Override
	public boolean saveCustomer(CustomerData oRequest) {
	    return customerRepository.save(oRequest) != null;
	}

}
